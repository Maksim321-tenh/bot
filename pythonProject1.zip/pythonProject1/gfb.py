import telebot
from telebot import types  # для указание типов
from time import sleep
import config
import logging
import datetime

bot = telebot.TeleBot(token = config.token, threaded=False, skip_pending=False)

@bot.message_handler(commands=['start'])
def start(message):
    markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
    btn1 = types.KeyboardButton("👋 Поздороваться")
    btn2 = types.KeyboardButton("❓ Задать вопрос")
    btn3 = types.KeyboardButton("📕 Агу")
    markup.add(btn1, btn2,btn3)
    bot.send_message(message.chat.id,
                     text="Привет, {0.first_name}! Я тестовый бот для работы с сайтом  https://rb.asu.ru".format(
                         message.from_user), reply_markup=markup)




@bot.message_handler(content_types=['text'])
def func(message):

    if (message.text == "👋 Поздороваться"):
        bot.send_message(message.chat.id, text="Привеет.. Спасибо что читаешь статью!)")
    elif (message.text == "❓ Задать вопрос"):
         bot.send_message(message.chat.id, text='Вопросы')

    elif(message.text == "📕 Агу"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("СПО")
        btn2 = types.KeyboardButton("ВО")
        back = types.KeyboardButton("Вернуться в главное меню")
        markup.add(btn1, btn2, back)
        bot.send_message(message.chat.id, text="Ты зашел на вкладку <Агу> что тебя интересует.", reply_markup=markup)
        # Работа с кнопкой СПО
    elif message.text == "СПО":
        markup = types.InlineKeyboardMarkup(row_width=1)
        btn1 =types.InlineKeyboardButton(text='Экономика и бухгалтерский учет (по отраслям)',url="https://rb.asu.ru/content/article/12657")
        btn2 =types.InlineKeyboardButton(text='Финансы', url="https://rb.asu.ru/content/article/12656",callback_data='2')
        btn3 =types.InlineKeyboardButton(text="Информационные системы и программирование",url="https://rb.asu.ru/content/article/12651")
        btn4 =types.InlineKeyboardButton(text='Правоохранительная деятельность',url="https://rb.asu.ru/content/article/12594")
        btn5 =types.InlineKeyboardButton(text='Земельно-имущественные отношения',url="https://rb.asu.ru/content/article/12592")
        markup.add(btn1,btn2,btn3,btn4,btn5)
        bot.send_message(message.chat.id,"Специальности среднего профессионального образования:" 
                                         "38.02.01. Экономика и бухгалтерский учет (по отраслям)\n"
                                         "38.02.06 Финансы\n"
                                         "09.02.07 Информационные системы и программирование\n"
                                         "40.02.02 Правоохранительная деятельность\n"
                                         "21.02.05 Земельно-имущественные отношения",reply_markup=markup)

        # Работа с кнопкой ВО
    elif message.text == "ВО":
        markup = types.InlineKeyboardMarkup(row_width=1)
        btn1 = types.InlineKeyboardButton(text='Педагогическое образование, профиль (Обществознание)',url="https://rb.asu.ru/content/article/13135")
        btn2 = types.InlineKeyboardButton(text='Прикладная информатика, профиль Цифровые технологии и управление данными', url="https://rb.asu.ru/content/article/12599")
        btn3 = types.InlineKeyboardButton(text="Юриспруденция, профиль Общеправовой",url="https://rb.asu.ru/content/article/12593")
        btn4 = types.InlineKeyboardButton(text='Реклама и связи с общественностью',url="https://rb.asu.ru/content/article/12591")
        btn5 = types.InlineKeyboardButton(text='Экономика, профиль (Цифровая экономика и финансы)',url="https://rb.asu.ru/content/article/12583")
        btn6=types.InlineKeyboardButton(text='Психология, профиль (Общая психология и психология личности)',url="https://rb.asu.ru/content/article/12580")
        btn7 =types.InlineKeyboardButton(text='Государственное и муниципальное управление, профиль Цифровое государство',url="https://rb.asu.ru/content/article/12574")
        markup.add(btn1, btn2, btn3, btn4, btn5,btn6,btn7)
        bot.send_message(message.chat.id, "Направления подготовки высшего образования:\n"
                                          "44.03.01 Педагогическое образование, профиль (Обществознание)\n"
                                          "09.03.03 Прикладная информатика, профиль Цифровые технологии и управление данными\n"
                                          "40.03.01 Юриспруденция, профиль Общеправовой\n"
                                          "42.03.01 Реклама и связи с общественностью\n"
                                          "38.03.01 Экономика, профиль (Цифровая экономика и финансы)\n"
                                          "37.03.01 Психология, профиль (Общая психология и психология личности)\n"
                                          "38.03.04 Государственное и муниципальное управление, профиль Цифровое государство",reply_markup=markup)


    # Работа с кнопкой Как Меня зовут(Кнопка будет редактироваться)
    elif message.text == "Как меня зовут?":
        bot.send_message(message.chat.id, "У меня нет имени..")
    # Работа с кнопкой Что я могу(Кнопка будет редактироваться)
    elif message.text == "Что я могу?":
        bot.send_message(message.chat.id, text="Поздороваться с читателями")
    # Работа с кнопкойВернуться в главное меню
    elif (message.text == "Вернуться в главное меню"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        button1 = types.KeyboardButton("👋 Поздороваться")
        button2 = types.KeyboardButton("❓ Задать вопрос")
        button3 = types.KeyboardButton("📕 Агу")
        markup.add(button1, button2,button3)
        bot.send_message(message.chat.id, text="Вы вернулись в главное меню", reply_markup=markup)
    else:
       bot.send_message(message.chat.id, text="На такую комманду я не запрограммировал..")




bot.polling(none_stop=True)